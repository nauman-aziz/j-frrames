/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3tiers;

/**
 *
 * @author GOOGLE CORE
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class manager {
    
    void write(String data,String filename) throws IOException
    {
        FileWriter fw = null;
        BufferedWriter bw = null;
        try
        {
            fw = new FileWriter(filename,true);
            bw = new BufferedWriter(fw);
            bw.write(data);
            bw.newLine();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
            
        {
            if(bw!=null)
            {
                bw.close();
            }
            if(fw!=null)
            {
                fw.close();
            }
        }
    }
        String readCarID(String filename) throws IOException
    {
        FileReader fr = null;
        BufferedReader br = null;
        String line=null;
        String data = "Select Car ID";
        String carid =null,make =null,model=null,avail=null;
        try
        {
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            while((line=br.readLine())!=null )
            {
               carid = line;
               make = br.readLine();
               model = br.readLine();
               avail = br.readLine();
               
               data = data +","+ carid;
               
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(br!=null);
             br.close();
            if(fr!=null)
             fr.close();
        }
        return data;
    }
    String readCarAvail(String filename) throws IOException
    {
        FileReader fr = null;
        BufferedReader br = null;
        String line=null;
        String data = "";
        String carid =null,make =null,model=null,avail=null;
        try
        {
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            while((line=br.readLine())!=null )
            {
               carid = line;
               make = br.readLine();
               model = br.readLine();
               avail = br.readLine();
               
               data = data +","+ avail;
               
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(br!=null);
             br.close();
            if(fr!=null)
             fr.close();
        }
        return data;
    }
    String readCar(String filename) throws IOException
    {
        FileReader fr = null;
        BufferedReader br = null;
        String line=null;
        String data = "";
        String carid =null,make =null,model=null,avail=null;
        try
        {
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            while((line=br.readLine())!=null )
            {
               data = data + ","+line;
               
            }
            System.out.println(data);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(br!=null);
             br.close();
            if(fr!=null)
             fr.close();
        }
        return data;
    }
    String readCustomer(String filename) throws IOException
    {
        FileReader fr = null;
        BufferedReader br = null;
        String line=null;
        String data = "";
        String carid =null,make =null,model=null,avail=null;
        try
        {
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            while((line=br.readLine())!=null )
            {
               data = data + ","+line;
               
            }
            System.out.println(data);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(br!=null);
             br.close();
            if(fr!=null)
             fr.close();
        }
        return data;
    }
    boolean Delete(String data,File filename) throws IOException
    {
        boolean flag;
        ArrayList<caradd_1> ilist = new ArrayList<caradd_1>();
        FileReader fr = null;
        File file = new File("temp.txt");
        BufferedReader br = null;
        FileWriter fw = null;
        BufferedWriter bw = null;
        String line = null;
        String data1 = "";
        String icarid="",imake="",imodel="",iavail="";
        StringTokenizer str = new StringTokenizer(data,",");
        while(str.hasMoreTokens())
        {
            icarid = str.nextToken();
            imake = str.nextToken();
            imodel = str.nextToken();
            iavail = str.nextToken();
            
        }
        try
        {
            fw = new FileWriter(file,true);
            bw = new BufferedWriter(fw);
            String carid,make,model,avail;
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            while((line=br.readLine())!=null)
            {
               carid = line;
               make = br.readLine();
               model = br.readLine();
               avail = br.readLine();
               if((!icarid.equals(carid)) && (!imake.equals(make)) && (!imodel.equals(model)) && (!imake.equals(make)))
               {
                   int id = Integer.parseInt(carid);
                   int mod = Integer.parseInt(model);
                  ilist.add(new caradd_1(id,make,mod,avail));
               }
            }
            for(int i=0;i<ilist.size();i++)
            {
                bw.write(ilist.get(i).toString());
                bw.newLine();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
            
        {
            if(br!=null)
            {
                br.close();
            }
            if(fr!=null)
            {
                fr.close();
            }
            if(bw!=null)
            {
                bw.close();
            }
            if(fw!=null)
            {
                fw.close();
            }
            filename.delete();
            flag=file.renameTo(new File("carrent.txt"));
        }
        return flag;
    }
    String Search(String datap,String filename) throws IOException
    {
        FileReader fr = null;
        BufferedReader br = null;
        String line=null;
        String data = "";
        String iname="",icompany="";
        StringTokenizer str;
        str = new StringTokenizer(datap,",");
        while(str.hasMoreTokens())
        {
            iname = str.nextToken();
            icompany = str.nextToken();
        }       
        try
        {
            String name="",company=""; int price=0,quantity=0; double weight = 0.0;
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            while((line=br.readLine())!=null )
            {
                str = new StringTokenizer(line,",");
                while(str.hasMoreTokens())
                {
                    name = str.nextToken();
                    company = str.nextToken();
                    price = Integer.parseInt(str.nextToken());
                    weight = Double.parseDouble(str.nextToken());
                    quantity = Integer.parseInt(str.nextToken());
                    //System.out.println(name);
                if(icompany.equals(company)&& (iname.equals(name)))
                {
                    data=data+line;
                }
                } 
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(br!=null);
             br.close();
            if(fr!=null)
             fr.close();
        }
        return data;
    }
     void Update(String data,File filename) throws IOException
    {
        StringTokenizer str;
        ArrayList<caradd_1> ilist = new ArrayList<caradd_1>();
        FileReader fr = null;
        File file = new File("temp.txt");
        BufferedReader br = null;
        FileWriter fw = null;
        BufferedWriter bw = null;
        String line = null;
        String data1 = "";
        String icarid="",imake="",imodel="",iavail="";
        str = new StringTokenizer(data,",");
        while(str.hasMoreTokens())
        {
            icarid = str.nextToken();
            imake = str.nextToken();
            imodel = str.nextToken();
            iavail = str.nextToken();
            
        }
        try
        {
            fw = new FileWriter(file,true);
            bw = new BufferedWriter(fw);
            String carid,make,model,avail;
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            while((line=br.readLine())!=null)
            {
               carid = line;
               make = br.readLine();
               model = br.readLine();
               avail = br.readLine();
               if((!icarid.equals(carid)) && (!imake.equals(make)) && (!imodel.equals(model)) && (!imake.equals(make)))
               {
                   int id = Integer.parseInt(carid);
                   int mod = Integer.parseInt(model);
                  ilist.add(new caradd_1(id,make,mod,avail));
               }
               else
               {
                   carid = icarid; model = imodel; make = imake; avail = iavail;
                   int id = Integer.parseInt(carid);
                   int mod = Integer.parseInt(model);
                   ilist.add(new caradd_1(id,make,mod,avail));
               }
            }
           for(int i=0;i<ilist.size();i++)
            {
                bw.write(ilist.get(i).toString());
                bw.newLine();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
            
        {
            if(br!=null)
            {
                br.close();
            }
            if(fr!=null)
            {
                fr.close();
            }
            if(bw!=null)
            {
                bw.close();
            }
            if(fw!=null)
            {
                fw.close();
            }
            filename.delete();
            file.renameTo(new File("carrent.txt"));
        }
    }

 }
    
