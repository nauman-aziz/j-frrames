
package project3tiers;


import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author GOOGLE CORE
 */
public class rentail extends javax.swing.JFrame {
	
	
    public rentail() {
        initComponents();


    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbldate = new javax.swing.JPanel();
        idcomb = new javax.swing.JComboBox();
        lblcarid = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_custid = new javax.swing.JTextField();
        lblcnam = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        lbldue = new javax.swing.JLabel();
        btnokk = new javax.swing.JButton();
        txtaval = new javax.swing.JTextField();
        btncan = new javax.swing.JButton();
        lblRfee = new javax.swing.JLabel();
        txtfee = new javax.swing.JTextField();
        lblaval = new javax.swing.JLabel();
        txtdue = new javax.swing.JTextField();
        txtdate1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        lbldate.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rental", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        idcomb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idcombActionPerformed(evt);
            }
        });

        lblcarid.setText("Car ID");

        jLabel2.setText("Customer ID");

        lblcnam.setText("Customer Name");

        jLabel4.setText("Date");

        lbldue.setText("Due Date");

        btnokk.setText("ok");
        btnokk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnokkActionPerformed(evt);
            }
        });

        btncan.setText("Cancel");
        btncan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncanActionPerformed(evt);
            }
        });

        lblRfee.setText("Retail fee");

        lblaval.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblaval.setText("Available");

        txtdue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdueActionPerformed(evt);
            }
        });

        txtdate1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdate1ActionPerformed(evt);
            }
        });

        jButton1.setText("Import Car Data");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout lbldateLayout = new javax.swing.GroupLayout(lbldate);
        lbldate.setLayout(lbldateLayout);
        lbldateLayout.setHorizontalGroup(
            lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lbldateLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(lbldateLayout.createSequentialGroup()
                        .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(lbldateLayout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addGap(26, 26, 26)
                                    .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(idcomb, 0, 140, Short.MAX_VALUE)
                                        .addComponent(txt_custid)))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lbldateLayout.createSequentialGroup()
                                    .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4)
                                        .addComponent(lbldue))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                                    .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtfee, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                                        .addComponent(txtdue)
                                        .addComponent(txtdate1))))
                            .addComponent(lblcarid, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(lbldateLayout.createSequentialGroup()
                                .addComponent(lblcnam)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblRfee))
                        .addGap(37, 37, 37)
                        .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lbldateLayout.createSequentialGroup()
                                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtaval, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblaval, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(32, 32, 32))
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(lbldateLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnokk, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btncan, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
        );
        lbldateLayout.setVerticalGroup(
            lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbldateLayout.createSequentialGroup()
                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lbldateLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblcarid)
                            .addComponent(idcomb, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txt_custid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(lbldateLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(lblaval)
                        .addGap(18, 18, 18)
                        .addComponent(txtaval, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(16, 16, 16)
                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblcnam)
                    .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRfee)
                    .addComponent(txtfee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtdate1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbldue)
                    .addComponent(txtdue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(lbldateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnokk, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btncan, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbldate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(lbldate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void btnokkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnokkActionPerformed
        // TODO add your handling code here:
        
         /*String car_id = idcomb.getSelectedItem().toString();
                    String custId = txt_custid.getText();
                    int ID=Integer.parseInt(custId);
                    String na= txtname.getText();
                    String renfee =  txtfee.getText();
                    int Rfee=Integer.parseInt(renfee);
                    String date = txtdate1.getText();
                    String due = txtdue.getText();
                    rentail_1 car = new rentail_1(car_id,ID,na,Rfee,date,due);
                    String file = "carrent.txt";
                    try {
                    rentail.write(car.toString(), file);
                    } catch (IOException ex) {
                    Logger.getLogger(caradd.class.getName()).log(Level.SEVERE, null, ex);
                    }*/


            JOptionPane.showMessageDialog(this, "Sucsessfully Saved");

    }//GEN-LAST:event_btnokkActionPerformed


    private void idcombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idcombActionPerformed
        // TODO add your handling code here:
             // System.out.println(idcomb.getSelectedItem().toString());
             // System.out.println(idcomb.getSelectedIndex());
                manager rentail=new manager();
        String data = null;
        String filename= "carrent.txt";
        try {
          //  System.out.println(rentail.readCarAvail(filename));
            data = rentail.readCarAvail(filename);
                   
        } catch (IOException ex) {
            Logger.getLogger(rentail.class.getName()).log(Level.SEVERE, null, ex);
        } 
        StringTokenizer strf = new StringTokenizer(data,",");
        int count = strf.countTokens();
        //System.out.println(count);
       int i=0;
        String avail[]= new String[count];
          while(strf.hasMoreTokens())
               {
                   avail[i] = strf.nextToken();
                   i++;
                }
          if(idcomb.getSelectedIndex() == 0)
          {
              txtaval.setText("");
          }else{
              int index = idcomb.getSelectedIndex()-1;
              //System.out.println(index);
              txtaval.setText(avail[index]);
              
              System.out.println(avail[index]);
              if(avail[index].equals("Yes")){
                btnokk.setVisible(true);
                txt_custid.setEditable(true);
                txtdate1.setEditable(true);
                txtdue.setEditable(true);
                txtfee.setEditable(true);
                txtname.setEditable(true); 
              }else{
                btnokk.setVisible(false);
                txt_custid.setEditable(false);
                txtdate1.setEditable(false);
                txtdue.setEditable(false);
                txtfee.setEditable(false);
                txtname.setEditable(false);
                
              }
          }
          
             // txtaval.setText(avail[index]);
                //JOptionPane.showMessageDialog(null, "Car No not Found");
  
    }//GEN-LAST:event_idcombActionPerformed

    private void btncanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncanActionPerformed
        // TODO add your handling code here:
         setVisible(false);
        dispose();
    }//GEN-LAST:event_btncanActionPerformed

    private void txtdueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdueActionPerformed

    private void txtdate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdate1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdate1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         manager rentail=new manager();
        String data = null;
        String filename= "carrent.txt";
        try {
           // System.out.println(rentail.readCarID(filename));
            data = rentail.readCarID(filename);
                   
        } catch (IOException ex) {
            Logger.getLogger(rentail.class.getName()).log(Level.SEVERE, null, ex);
        } 
        StringTokenizer strf = new StringTokenizer(data,",");
        int count = strf.countTokens();
        //System.out.println(count); 
        int i=0;
        String carid[]= new String[count];
          while(strf.hasMoreTokens())
               {
                   carid[i] = strf.nextToken();
                   i++;
                }

               idcomb.setModel(new DefaultComboBoxModel<>(carid));
               jButton1.setVisible(false);
              //System.out.println(idcomb.getSelectedItem());
          //btnokk.setEnabled(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(rentail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(rentail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(rentail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(rentail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
    
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               new rentail().setVisible(true);
                btnokk.setVisible(false);
                txt_custid.setEditable(false);
                txtaval.setEditable(false);
                txtdate1.setEditable(false);
                txtdue.setEditable(false);
                txtfee.setEditable(false);
                txtname.setEditable(false);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncan;
    private static javax.swing.JButton btnokk;
    private static javax.swing.JComboBox idcomb;
    private javax.swing.JButton jButton1;
    private static javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblRfee;
    private javax.swing.JLabel lblaval;
    private javax.swing.JLabel lblcarid;
    private javax.swing.JLabel lblcnam;
    private javax.swing.JPanel lbldate;
    private javax.swing.JLabel lbldue;
    private static javax.swing.JTextField txt_custid;
    private static javax.swing.JTextField txtaval;
    private static javax.swing.JTextField txtdate1;
    private static javax.swing.JTextField txtdue;
    private static javax.swing.JTextField txtfee;
    private static javax.swing.JTextField txtname;
    // End of variables declaration//GEN-END:variables
}
