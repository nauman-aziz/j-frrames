package project3tiers;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GOOGLE CORE
 */
public class customer_1 {
    private int customerID;
    private String mobileName;
    private String customerAdress;
    private int customerMob;

    public customer_1(int customerID, String mobileName, String customerAdress, int customerMob) {
        this.customerID = customerID;
        this.mobileName = mobileName;
        this.customerAdress = customerAdress;
        this.customerMob = customerMob;
    }

    public int getCustomerID() {
        return customerID;
    }

    public String getMobileName() {
        return mobileName;
    }

    public String getCustomerAdress() {
        return customerAdress;
    }

    public int getCustomerMob() {
        return customerMob;
    }

    @Override
    public String toString() {
        return  customerID+"\n"+ mobileName+"\n" + customerAdress+"\n"+ customerMob ;
    }

}