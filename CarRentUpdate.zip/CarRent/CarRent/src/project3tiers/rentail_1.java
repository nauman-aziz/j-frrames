package project3tiers;


import java.util.GregorianCalendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GOOGLE CORE
 */
public class rentail_1 {
      private int carId;
    private int customerId;
    private String customerName;
    private int retalifee;
    public GregorianCalendar date;
    public GregorianCalendar dueDate;
    private int monthlyProfit;

    public int getMonthlyProfit() {
        return monthlyProfit;
    }

    public void setMonthlyProfit(int monthlyProfit) {
        this.monthlyProfit = monthlyProfit;
    }
    

    public rentail_1(int carId, int customerId, String customerName, int retalifee, GregorianCalendar date, GregorianCalendar dueDate) {
        this.carId = carId;
        this.customerId = customerId;
        this.customerName = customerName;
        this.retalifee = retalifee;
        this.date = date;
        this.dueDate = dueDate;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getRetalifee() {
        return retalifee;
    }

    public GregorianCalendar getDate() {
        return date;
    }

    public GregorianCalendar getDueDate() {
        return dueDate;
    }

    @Override
    public String toString() {
        return  carId + "\n"+ customerId + "\n" +customerName+"\n" + retalifee + "\n"+ date+"\n"+ dueDate;
    }

    
}