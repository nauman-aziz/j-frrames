package project3tiers;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GOOGLE CORE
 */
public class caradd_1 {
    private int Car_Reg_No;
    private String make;
    private int model;
    private String available;

    public caradd_1(int Car_Reg_No, String make, int model,String available) {
        this.Car_Reg_No = Car_Reg_No;
        this.make = make;
        this.model = model;
         this.available = available;
    }

    public int getCar_Reg_No() {
        return Car_Reg_No;
    }

    public String getMake() {
        return make;
    }

    public int getModel() {
        return model;
    }

    public String getAvailable() {
        return available;
    }

    public void setCar_Reg_No(int Car_Reg_No) {
        this.Car_Reg_No = Car_Reg_No;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(int model) {
        this.model = model;
    }

    @Override
    public String toString() {
        return Car_Reg_No + "\n" + make + "\n" + model + "\n" + available;
    }
    
}
